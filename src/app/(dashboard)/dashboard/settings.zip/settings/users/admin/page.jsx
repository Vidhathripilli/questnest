'use client';

import React from 'react';

export default function AdminPage() {
  return (
    <div className="p-6">
      {/* Breadcrumb */}
      <div className="text-sm text-gray-500 mb-6">
        User's &gt; <span className="text-gray-700 font-semibold">Admin</span>
      </div>

      {/* School Owner Section */}
      <div className="bg-white p-6 rounded-lg shadow mb-8">
        <h2 className="text-lg font-semibold text-gray-800 mb-4">School Owner</h2>

        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="flex items-center justify-center w-10 h-10 rounded-full bg-purple-100 text-purple-700 font-bold">
              BC
            </div>
            <div>
              <p className="font-semibold text-gray-800">Bharat Chander</p>
              <p className="text-xs text-gray-500">Owner</p>
            </div>
          </div>

          <button className="px-4 py-2 bg-white border border-purple-700 text-purple-700 rounded-md hover:bg-purple-50 text-sm font-medium">
            Transfer Ownership
          </button>
        </div>
      </div>

      {/* Admins Section */}
      <div className="bg-white p-6 rounded-lg shadow">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-semibold text-gray-800">Admin's</h2>
          <button className="px-4 py-2 bg-[#402BA3] text-white rounded-md hover:bg-purple-800 text-sm font-medium">
            Add Admin
          </button>
        </div>

        {/* Admin Table */}
        <div className="w-full border rounded-lg overflow-hidden">
          <table className="w-full text-sm text-left">
            <thead className="bg-purple-100 text-gray-700 text-sm">
              <tr>
                <th className="px-4 py-3">Name</th>
                <th className="px-4 py-3">Email</th>
                <th className="px-4 py-3">Role</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3">Actions</th>
              </tr>
            </thead>
            <tbody>
              {/* No Admin Found */}
              <tr>
                <td colSpan="5" className="text-center py-8 text-gray-500">
                  No Admin added yet
                  <div className="mt-4">
                    <button className="px-6 py-2 bg-[#402BA3] text-white rounded-md hover:bg-purple-800 text-sm font-medium">
                      Add Admin
                    </button>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
